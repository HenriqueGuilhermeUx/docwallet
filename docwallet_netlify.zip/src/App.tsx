import { useState } from 'react';
import { useDocumentsWithAuth } from './hooks/useDocumentsWithAuth';
import { DocumentType } from './types/document';
import { Document } from './types/document';
import {
  Header,
  Hero,
  SearchBar,
} from './components/Header';
import { CategoryTabs } from './components/CategoryTabs';
import { DocumentGrid } from './components/DocumentGrid';
import { FloatingActionButton } from './components/FloatingActionButton';
import { Toast } from './components/Toast';
import { AddDocumentModal } from './components/AddDocumentModal';
import { DocumentViewerModal } from './components/DocumentViewerModal';
import { AuthModal } from './components/AuthModal';
import { LogOut, UserCircle } from 'lucide-react';

function App() {
  const {
    user,
    documents,
    allDocuments,
    activeCategory,
    setActiveCategory,
    searchQuery,
    setSearchQuery,
    addDocument,
    deleteDocument,
    getCategoryCount,
    handleLogout,
    toast,
    isLoading,
    isAuthLoading,
  } = useDocumentsWithAuth();

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleAddClick = () => {
    if (!user) {
      setShowAuthModal(true);
    } else {
      setShowAddModal(true);
    }
  };

  const handleAddDocument = async (
    name: string,
    type: DocumentType,
    file: File
  ) => {
    await addDocument(name, type, file);
  };

  const handleDocumentClick = (doc: Document) => {
    setSelectedDocument(doc);
  };

  const handleHeaderAction = () => {
    if (user) {
      handleLogout();
    } else {
      setShowAuthModal(true);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header
        onAddClick={handleAddClick}
        user={user}
        onLogout={handleHeaderAction}
      />

      {!user ? (
        <div className="flex flex-col items-center justify-center py-16 px-4">
          <div className="w-24 h-24 bg-gradient-to-br from-primary to-primary-dark rounded-full flex items-center justify-center mb-6 shadow-lg">
            <UserCircle className="text-white" size={48} />
          </div>
          <h3 className="text-2xl font-bold text-slate-800 mb-3">
            Bem-vindo ao DocWallet
          </h3>
          <p className="text-slate-500 text-center max-w-md mb-8">
            A sua carteira digital de documentos. Faça login ou cadastre-se para começar a organizar seus documentos de forma segura.
          </p>
          <button
            onClick={() => setShowAuthModal(true)}
            className="px-8 py-3 bg-primary hover:bg-primary-dark text-white rounded-full font-semibold transition-colors shadow-lg"
          >
            Entrar ou Cadastrar
          </button>
        </div>
      ) : (
        <>
          <Hero
            documentCount={allDocuments.length}
            onAddClick={handleAddClick}
          />

          <SearchBar value={searchQuery} onChange={setSearchQuery} />

          <CategoryTabs
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
            getCategoryCount={getCategoryCount}
          />

          <DocumentGrid
            documents={documents}
            onDocumentClick={handleDocumentClick}
            isLoading={isLoading}
          />

          <FloatingActionButton onClick={handleAddClick} />
        </>
      )}

      {showAddModal && user && (
        <AddDocumentModal
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddDocument}
        />
      )}

      {selectedDocument && (
        <DocumentViewerModal
          document={selectedDocument}
          onClose={() => setSelectedDocument(null)}
          onDelete={deleteDocument}
        />
      )}

      {showAuthModal && (
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => {}}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  );
}

export default App;